# Bot de Minas (5x5)

App Streamlit - Tabuleiro 5x5, tema dourado, descrição curta.

Instruções de deploy no Streamlit Cloud incluídas.
