import streamlit as st
import random
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont

st.set_page_config(page_title="Bot de Minas", layout="wide", page_icon="💣")
st.title("💰 Bot de Minas")
st.markdown("**Bot para jogo de Minas**")

# --- Controls ---
col1, col2 = st.columns([2,1])
with col1:
    grid_rows = 5
    grid_cols = 5
    positions = grid_rows * grid_cols
    mines = st.slider("Número de minas no tabuleiro", min_value=1, max_value=positions-1, value=3)
    n_sim = st.number_input("Simulações Monte Carlo (para estimar probabilidades condicionais)", min_value=1000, max_value=200000, value=20000, step=1000)
with col2:
    st.markdown("**Estado atual do tabuleiro**")
    st.markdown("Toque nas células para marcá-las: ✔ seguro → 💣 mina → vazio. Use 'Limpar' para reiniciar.")

# --- Initialize state ---
if 'known_safe' not in st.session_state:
    st.session_state['known_safe'] = set()
if 'known_mine' not in st.session_state:
    st.session_state['known_mine'] = set()
if 'sim_results' not in st.session_state:
    st.session_state['sim_results'] = None

def reset_board():
    st.session_state['known_safe'] = set()
    st.session_state['known_mine'] = set()
    st.session_state['sim_results'] = None

# Grid interaction
st.write("### Tabuleiro (5x5) - clique para alternar estado: ✔ seguro → 💣 mina → vazio")
for r in range(grid_rows):
    cols = st.columns(grid_cols)
    for c in range(grid_cols):
        idx = r * grid_cols + c
        if idx in st.session_state['known_safe']:
            label = f"✔\n{idx}"
        elif idx in st.session_state['known_mine']:
            label = f"💣\n{idx}"
        else:
            label = f"{idx}"
        if cols[c].button(label, key=f"cell_{idx}"):
            # toggle: none -> safe -> mine -> none
            if idx not in st.session_state['known_safe'] and idx not in st.session_state['known_mine']:
                st.session_state['known_safe'].add(idx)
            elif idx in st.session_state['known_safe']:
                st.session_state['known_safe'].remove(idx)
                st.session_state['known_mine'].add(idx)
            else:
                st.session_state['known_mine'].remove(idx)
            st.session_state['sim_results'] = None

c1, c2, c3 = st.columns([1,1,1])
with c1:
    if st.button("Executar simulação (calcular probabilidades)"):
        if len(st.session_state['known_mine']) > mines:
            st.warning("Número de minas conhecidas maior que número total de minas configurado. Ajuste as marcas.")
        else:
            all_indices = set(range(positions))
            fixed_mines = set(st.session_state['known_mine'])
            fixed_safe = set(st.session_state['known_safe'])
            remaining_indices = list(sorted(all_indices - fixed_mines - fixed_safe))
            remaining_mines = mines - len(fixed_mines)
            counts_safe = np.zeros(positions, dtype=np.int64)
            for i in range(int(n_sim)):
                placed = set(random.sample(remaining_indices, remaining_mines)) if remaining_mines>0 else set()
                mines_set = placed.union(fixed_mines)
                for idx in range(positions):
                    if idx in fixed_safe:
                        counts_safe[idx] += 1
                    else:
                        if idx not in mines_set:
                            counts_safe[idx] += 1
            probs_safe = counts_safe / n_sim
            st.session_state['sim_results'] = probs_safe.tolist()
            st.success("Simulação concluída.")
with c2:
    if st.button("Limpar marcas"):
        reset_board()
with c3:
    if st.button("Exportar probabilidades (CSV)"):
        if st.session_state.get('sim_results') is None:
            st.warning("Rode a simulação antes de exportar.")
        else:
            df = pd.DataFrame({
                "cell": list(range(positions)),
                "prob_safe": st.session_state['sim_results']
            })
            csv = df.to_csv(index=False).encode('utf-8')
            st.download_button("Download CSV", csv, file_name="probabilidades_casas_5x5.csv", mime="text/csv")

# --- Show probabilities grid ---
st.write("### Probabilidades estimadas por célula (maior = mais segura)")
probs = st.session_state.get('sim_results')
if probs is None:
    st.info("Sem resultados. Clique em 'Executar simulação' para estimar probabilidades condicionais.")
    baseline = 1.0 - (mines / positions)
    st.write(f"Probabilidade baseline de uma casa ser segura (sem informação): {baseline:.4f}")
    df_basic = pd.DataFrame({
        "cell": list(range(positions)),
        "prob_safe_baseline": [baseline]*positions
    })
    st.dataframe(df_basic.style.format({ "prob_safe_baseline":"{:.4f}"}))
else:
    img_w = 60 * grid_cols
    img_h = 60 * grid_rows
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGB", (img_w, img_h), color=(12,12,12))
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("arial.ttf", 14)
    except:
        from PIL import ImageFont
        font = ImageFont.load_default()
    for r in range(grid_rows):
        for c in range(grid_cols):
            idx = r*grid_cols + c
            p = probs[idx]
            if idx in st.session_state['known_safe']:
                fill = (30,100,30)
            elif idx in st.session_state['known_mine']:
                fill = (120,20,20)
            else:
                g = int(180 * p + 40)
                rcol = int(200 * (1-p) + 40)
                fill = (min(rcol,255), min(g,255), 40)
            x0 = c*60; y0 = r*60; x1 = x0+59; y1 = y0+59
            draw.rectangle([x0,y0,x1,y1], fill=fill, outline=(80,80,80))
            draw.text((x0+6, y0+8), f"{idx}", fill=(0,0,0), font=font)
            draw.text((x0+6, y0+28), f"{p:.1%}", fill=(0,0,0), font=font)
    st.image(img, use_column_width=False, width=img_w)
    df = pd.DataFrame({
        "cell": list(range(positions)),
        "prob_safe": probs
    })
    st.dataframe(df.style.format({"prob_safe":"{:.4f}"}))

st.markdown("---")
st.markdown("**Como funciona:** o simulador gera aleatoriamente distribuições de minas condicionadas às marcas que você fez (casas já abertas ou minas conhecidas). A probabilidade exibida é a frequência empírica de cada casa ser **segura** nas simulações. Ferramenta educativa — não automatiza apostas.")